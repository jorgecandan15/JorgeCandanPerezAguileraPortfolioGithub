#include <iostream>
#include <ctime>    //Para srand y time
#include <windows.h> //Para Sleep

using namespace std;

//Estructura para crear un jugador
struct Jugador {
    string nombre;
    string apellido;
    int dinero;  //Saldo
    int apuesta; //Apuesta
};

//Declaracion de funciones
void inicializarPuente(int puente[], int tamano);
void mostrarPuente(int puente[], int tamano, int posicion);
bool cruzarPuente(int puente[], int tamano, Jugador jugador);

//Programa principal
int main() {
    //Limpiar terminal
    system("cls");
    //Titulo
    cout << endl;
    cout << endl;
    cout << endl;
    cout << "    _____  _    _ ______ _   _ _______ ______   ______ ______  _____         _____ \n";
    cout << "   |  __ \\| |  | |  ____| \\ | |__   __|  ____| |  ____|  ____|/ ____|  /\\   / ____|\n";
    cout << "   | |__) | |  | | |__  |  \\| |  | |  | |__    | |__  | |__  | (___   /  \\ | |     \n";
    cout << "   |  ___/| |  | |  __| | . ` |  | |  |  __|   |  __| |  __|  \\___ \\ / /\\ \\| |     \n";
    cout << "   | |    | |__| | |____| |\\  |  | |  | |____  | |    | |____ ____) / ____ \\ |____ \n";
    cout << "   |_|     \\____/|______|_| \\_|  |_|  |______| |_|    |______|_____/_/    \\_\\_____|\n";
    cout << endl;
    cout << endl;
    cout << "                                      /\\       ******  " << endl;
    cout << "                        *******      /  \\     *      * " << endl;
    cout << "                        *     *     /    \\    *      * " << endl;
    cout << "                        *     *    /      \\   *      * " << endl;
    cout << "                        *******   /________\\   ******  " << endl;
    Sleep(2000);
    system("cls");

    //Menu inicial para solicitar datos del jugador
    cout << " ===============================\n";
    cout << "| Bienvenido al Puente de Cristal |\n";
    cout << " ===============================\n";
    cout << "Por favor, ingresa tus datos:\n";

    //Crear jugador
    Jugador jugador;

    cout << "Nombre: ";
    cin >> jugador.nombre;
    cout << "Apellido: ";
    cin >> jugador.apellido;
    cout << "Deposita tu saldo total: ";
    cin >> jugador.dinero;

    //Comprobar saldo inicial
    while (jugador.dinero <= 0) {
        cout << "El saldo inicial debe ser mayor a 0. Por favor, ingresa un saldo valido: ";
        cin >> jugador.dinero;
    }

    system("cls");
    cout << "Bienvenido " << jugador.nombre << " " << jugador.apellido << "! Tienes " << jugador.dinero << " euros disponibles para jugar.\n";

    string continuar;

    //Ciclo para permitir multiples partidas
    do {
        int tamanoPuente;
        int multiplicador;

        //Seleccion de nivel de dificultad
        cout << "Selecciona un nivel de dificultad:\n";
        cout << "1. Facil (Puente de tamano 2, Premio: 2x tu apuesta)\n";
        cout << "2. Medio (Puente de tamano 3, Premio: 3x tu apuesta)\n";
        cout << "3. Dificil (Puente de tamano 5, Premio: 999x tu apuesta)\n";
        int nivel;
        cin >> nivel;
        system("cls");

        //Configuracion segun el nivel
        if (nivel == 1) {
            tamanoPuente = 2;
            multiplicador = 2;
        } else if (nivel == 2) {
            tamanoPuente = 3;
            multiplicador = 3;
        } else if (nivel == 3) {
            tamanoPuente = 5;
            multiplicador = 999;
        } else {
            cout << "Nivel no valido. Se seleccionara el nivel Facil por intentar busar el bug, campeon.\n";
            tamanoPuente = 2;
            multiplicador = 2;
        }

        int puente[tamanoPuente];
        inicializarPuente(puente, tamanoPuente);

        //Mostrar dinero y pedir apuesta
        cout << "\nTienes " << jugador.dinero << " euros disponibles para apostar.\n";
        cout << "Cuanto quieres apostar? ";
        cin >> jugador.apuesta;

        //Validar apuesta
        while (jugador.apuesta > jugador.dinero || jugador.apuesta <= 0) {
            cout << "Apuesta invalida. Ingresa una cantidad entre 1 y " << jugador.dinero << ": ";
            cin >> jugador.apuesta;
        }

        //Jugar el puente y obtener el resultado
        bool gano = cruzarPuente(puente, tamanoPuente, jugador);

        //Actualizar el dinero del jugador segun el resultado
        if (gano) {
            cout << "\nFelicidades! Has cruzado el puente y ganado " << jugador.apuesta * multiplicador << " euros.\n";
            jugador.dinero += jugador.apuesta * multiplicador;
        } else {
            cout << "\nLo siento, perdiste. Has perdido tu apuesta.\n";
            jugador.dinero -= jugador.apuesta;
        }

        //Mostrar el resultado final
        cout << "\nAhora tienes " << jugador.dinero << " euros.\n";

        //Verificar si el jugador tiene dinero suficiente para continuar
        if (jugador.dinero <= 0) {
            cout << "Te quedaste sin dinero. Fin del juego.\n";
            break;
        }

        //Preguntar si desea continuar
        cout << "\nEscribe 'Jugar' para volver a jugar o cualquier otra cosa para irte a tu casita: ";
        cin >> continuar;

    } while (continuar == "jugar" || continuar == "Jugar" || continuar == "JUGAR");

    cout << "\nGracias por jugar, " << jugador.nombre << " " << jugador.apellido << ". No vuelvas!\n";

    return 0;
}

//Funcion para inicializar el puente con losas aleatorias
void inicializarPuente(int puente[], int tamano) {
    srand(time(NULL)); //Inicializar para generar numeros aleatorios
    for (int i = 0; i < tamano; i++) {
        puente[i] = rand() % 2; //Generar 0 o 1 aleatoriamente
    }
}

//Funcion para mostrar el estado del puente
void mostrarPuente(int puente[], int tamano, int posicion) {
    cout << "\nEstado del puente:\n";
    for (int i = 0; i < tamano; i++) {
        if (i < posicion) {
            //Mostrar el panel cruzado con una X en la posicion correcta
            if (puente[i] == 0) {
                cout << " [X] [ ] \n"; //Izquierda segura
            } else {
                cout << " [ ] [X] \n"; //Derecha segura
            }
        } else {
            //Mostrar los paneles aun no cruzados
            cout << " [?] [?] \n";
        }
    }
    cout << "\n";
}

//Funcion para jugar una ronda y determinar si el jugador gano
bool cruzarPuente(int puente[], int tamano, Jugador jugador) {
    int eleccion;
    int caida = 0;

    cout << "\nTe toca cruzar el puente, " << jugador.nombre << " " << jugador.apellido << "!\n";

    for (int i = 0; i < tamano && caida == 0; i++) {
        mostrarPuente(puente, tamano, i); //Mostrar estado del puente

        cout << "Panel " << i + 1 << ": Izquierda (1) o Derecha (2): ";
        cin >> eleccion;

        //Validar eleccion
        if (eleccion < 1 || eleccion > 2) {
            cout << "Eleccion invalida. Pierdes automaticamente.\n";
            caida = 1; //Marca como caida
        } else if (puente[i] != eleccion - 1) {
            cout << "Elegiste un panel fragil. Caiste al vacio!\n";
            caida = 1; //Marca como caida
        } else {
            cout << "Panel seguro! Continuas avanzando.\n";
        }
    }

    //Mostrar el puente finalizado
    if (caida == 0) {
        mostrarPuente(puente, tamano, tamano); //Mostrar puente completamente cruzado
    }

    //Retornar verdadero si no hubo caida, falso en caso contrario
    return (caida == 0);
}
