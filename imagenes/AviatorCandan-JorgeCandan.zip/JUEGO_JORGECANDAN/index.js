//Variables
let saldo = 100
//Indica si el avión está volando
let enVuelo = false
//Indica si el avión se ha estrellado
let seEstrello = false
//Valor en el que el avión explota (multiplicador final)
let puntoExplosion = 0
//Indica si el jugador se ha retirado antes de explotar
let seRetiro = false
//Multiplicador atual (el numero 100 representa el 1.00x)
let multiplicador = 100
let apuestaActual = 0
//Con esto ponemos cuánto queremos que vaya subiendo el multiplicador en cada paso (en este aso de uno en uno, es decir 1 = 0.01x)
let incremento = 1

let textoMultiplicador = document.getElementById("multiplicador")
let botonInicio = document.getElementById("botonInicio")
let botonRetirarse = document.getElementById("aterrizarAvion")
let textoResultado = document.getElementById("resultado")
let inputApuesta = document.getElementById("introducirApuesta")
let textoSaldo = document.getElementById("saldorestante")
let iconoAvion = document.getElementById("iconoAvion")
//Funcion para mostrar el saldo
function mostrarSaldo() {
  //Redondea el saldo a 2 decimales eliminando los decimales restantes y lo muestra
  let saldoRedondeado = Math.round(saldo * 100) / 100
  textoSaldo.innerText = "Saldo: " + saldoRedondeado + "€"
}
//Funcion para cambiar la imagen del avion
function cambiarIcono(nombre) {
  //Cambia la imagen del avión y su animaión según el estado
  if (nombre == "vuelo") {
    iconoAvion.style.backgroundImage = "url('avion.png')"
    //He añadido una animación de vuelo para que sea más visual
    //Sinceramente no tenia claro como poner la animacion en JS y he preguntado a Chatgpt sobre que usar para añadirla aqui,
    //y por eso use el .add y el .remove
    iconoAvion.classList.add("flotando") 
  }else if (nombre == "aterrizado") {
    iconoAvion.style.backgroundImage = "url('landing_3436523.png')"
    iconoAvion.classList.remove("flotando")
  }else if (nombre == "estrellado") {
    iconoAvion.style.backgroundImage = "url('crash_9617561.png')"
    iconoAvion.classList.remove("flotando")
  }
}
//Funcion para mostrar el multiplicador
function mostrarMultiplicador() {
  //Con esto convierto el número en string y lo muestra con el formato X.XXx
  let total = multiplicador + "" 
  if (total.length == 2) {
  //Si el número tiene solo 2 cifras por ejemplo 99 se pondra como 0.99x
  textoMultiplicador.innerText = "0." + total + "x"
  }else if (total.length == 3) {
  //Si tiene 3 cifras como 105 pasa a ser 1.05x
  //total[0] seria el 1 del 105, es decir la parte entera
  //y total[1] + total[2] seria el 05, es decir la la parte decimal
  textoMultiplicador.innerText = total[0] + "." + total[1] + total[2] + "x"
  } else if (total.length == 4) {
  //Si tiene 4 cifras como 1056, pasaria a "1056x"
  //total[0] + total[1] seria el 10, es decir la parte entera
  //total[2] + total[3] seria el 56, es decir la parte decimal
  textoMultiplicador.innerText = total[0] + total[1] + "." + total[2] + total[3] + "x"
  }

}

//Funion para crear un punto de choque
function crearExplosion() {
  //Decide aleatoriamente en que multipliador explota el avión
  let probabilidad = Math.random()
  let base = 0
  //Aqui le doy un porcentaje de probabilidad para complicar premios mas altos y rango de ganancia
  if (probabilidad < 0.08) {
    //8% de probabilidad de explosión alta (11.01x - 50.00x)
    base = 1101 + (Math.random() * (5000 - 1101 + 1))
  } else if (probabilidad < 0.7) {
    //70% de probabilidad de explosión baja (1.01x - 1.20x)
    base = 101 + (Math.random() * 20)
  } else {
    //22% de probabilidad de explosión media (1.21x - 11.00x)
    base = 121 + (Math.random() * (1100 - 121 + 1))
  }
  return base
}

//Funcion para avanzar el vuelo
function avanzarVuelo() {
  if (enVuelo == false) return
  //Sube el multiplicador
  multiplicador = multiplicador + incremento
  //Lo muestra en pantalla
  mostrarMultiplicador()

  //Si se alcanza el punto de explosión:
  if (multiplicador >= puntoExplosion) {
    enVuelo = false
    textoMultiplicador.style.color = "red"
    //Con los .disabled se desactiva el botón, en las paginas de refencia que nos dejas lo he encontrado
    botonInicio.disabled = false
    inputApuesta.disabled = false
    botonRetirarse.disabled = true

    if (seRetiro == false) {
      //Si el jugador no se retira y el avion choca, pierde su apuesta
      saldo = saldo - apuestaActual
      mostrarSaldo()
      cambiarIcono("estrellado")

      let multiFinal = Math.round(puntoExplosion) / 100
      multiFinal = Math.round(multiFinal * 100) / 100

      textoResultado.innerText = "Explotó en " + multiFinal + "x. Has perdido " + apuestaActual + "€"
    } else {
      //Si se retira usto antes de explotar
      cambiarIcono("estrellado")
    }

  } else {
    //Si no ha explotado aún, sigue aumentando
    //Con el setTimeout (encontrada tambien en las paginas de referencia) se le da un valor y cuanto mas le sumes mas lento irá
    setTimeout(avanzarVuelo, 100)
  }
}

//Iniciador del vuelo cuando pulseel boton
botonInicio.onclick = function () {
  let valor = inputApuesta.value

  //Alertas si las apuestas no son validas o no la ha realizado
  if (valor == "") {
    alert("Pon una apuesta")
    return
  }

  let apuesta = valor * 1
  if (apuesta <= 0 || apuesta > saldo) {
    alert("Apuesta no válida")
    return
  }

  //Guardamos la apuesta y se reinicia el vuelo
  apuestaActual = apuesta
  multiplicador = 100
  seRetiro = false
  seEstrello = false
  enVuelo = true

  //PConfiguraciones de colores de texto y bloqueo y activacion de los botones 
  textoMultiplicador.style.color = "lime"
  textoResultado.innerText = ""
  botonRetirarse.disabled = false
  botonInicio.disabled = true
  inputApuesta.disabled = true

  cambiarIcono("vuelo")
  puntoExplosion = crearExplosion()
  mostrarMultiplicador()
  avanzarVuelo()
}

//Boton para aterrizar
botonRetirarse.onclick = function () {
  if (enVuelo == false || seEstrello == true || seRetiro == true) return

  seRetiro = true

  //Calcular ganancia redondeada
  let ganancia = (apuestaActual * multiplicador) / 100
  ganancia = Math.round(ganancia * 100) / 100

  let multiFinal = Math.round(multiplicador) / 100
  multiFinal = Math.round(multiFinal * 100) / 100

  saldo = saldo + ganancia - apuestaActual
  mostrarSaldo()

  textoResultado.innerText = "Has aterrizado en " + multiFinal + "x. Has ganado " + ganancia + "€"
  textoMultiplicador.style.color = "lime"
  cambiarIcono("aterrizado")
  botonRetirarse.disabled = true
}

//Mostrar saldo final
mostrarSaldo()
